import React, { useState, useEffect } from 'react';
import wifi from './assets/images/wifi.png';
import './InternetSpeedChecker.css'; 

const InternetSpeedChecker = () => {
    const [isOnline, setIsOnline] = useState(navigator.onLine);
    const [speedLevel, setSpeedLevel] = useState('-');
    const [speedMbps, setSpeedMbps] = useState(0);
    const [showSpeedChecker, setShowSpeedChecker] = useState(false);

    useEffect(() => {
        const handleOnlineStatus = () => {
            setIsOnline(navigator.onLine);
            if (navigator.onLine) {
                checkInternetSpeed();
            } else {
                setSpeedLevel('--');
                setSpeedMbps(0);
            }
        };

        window.addEventListener('online', handleOnlineStatus);
        window.addEventListener('offline', handleOnlineStatus);

        // Start interval to check internet speed every second
        const intervalId = setInterval(() => {
            if (navigator.onLine) {
                checkInternetSpeed();
            }
        }, 1000); // Updates every second

        return () => {
            window.removeEventListener('online', handleOnlineStatus);
            window.removeEventListener('offline', handleOnlineStatus);
            clearInterval(intervalId); // Clear interval on unmount
        };
    }, []);

    const checkInternetSpeed = () => {
        const image = new Image();
        const startTime = new Date().getTime();
        const imageUrl = "https://demo70.sifyitest.com/livedata/speed/1mb.jpg"; // 1MB file

        image.onload = () => {
            const endTime = new Date().getTime();
            const duration = (endTime - startTime) / 1000; // in seconds
            const fileSizeInBytes = 1048576; // 1MB = 1048576 bytes
            const bitsLoaded = fileSizeInBytes * 8; // Convert to bits
            const speedBps = bitsLoaded / duration; // Bits per second
            const speedKbps = speedBps / 1024; // Kilobits per second
            const speedMbps = speedKbps / 1024; // Megabits per second

            setSpeedMbps(speedMbps.toFixed(2)); // Set speed in Mbps

            let speedLevel = 'Fast';
            if (speedMbps < 1) {
                speedLevel = 'Slow';
            } else if (speedMbps >= 1 && speedMbps < 5) {
                speedLevel = 'Medium';
            }
    
            setSpeedLevel(speedLevel);
    
            // Log the data to the backend
            logInternetStatus('On', speedLevel);

        };

        image.onerror = () => {
            setSpeedLevel('---');
            setSpeedMbps(0);
    
            // Log the data as "offline"
            logInternetStatus('Off', '---');
        };

        image.src = `${imageUrl}?time=${startTime}`; // Add timestamp to avoid caching
    };


const logInternetStatus = (status, level) => {
    fetch('http://localhost:5000/log-internet-speed', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ status, level }),
    })
    .then((response) => response.text())
    // .then((result) => console.log(result))
    .catch((error) => console.error('Error logging internet speed:', error));
};


    const speedBarWidth = () => {
        if (speedLevel === 'Slow') return 20;
        if (speedLevel === 'Medium') return 50;
        if (speedLevel === 'Fast') return 100;
        return 0;
    };

    const handleClick = () => {
        setShowSpeedChecker(!showSpeedChecker);
    };

    const handleClose = () => {
        setShowSpeedChecker(false);
    };

    return (
        <div className="internet-icon">
            <img src={wifi} style={{ width: '30px' }} onClick={handleClick} />
            <span className={isOnline ? "online-indicator" : "offline-indicator"}></span>
            <div className="internet-speed-checker" style={{ display: showSpeedChecker ? 'flex' : 'none' }}>
                <button className="close-wifi" onClick={handleClose}>X</button>
                <div className="speed-info">
                    <span className='status'><span className='badge'>Internet</span> <span className={isOnline ? "online" : "offline"}>{isOnline ? 'ON' : 'OFF'}</span></span>
                    <span className='speed'><span className='badge'>Speed</span> <p>{speedMbps} Mbps</p></span>
                    <span className='speed-level'><span className='badge'>Level</span> {speedLevel}</span>
                </div>
                <div className="speed-bar">
                    <div
                        className="speed-bar-fill"
                        style={{
                            width: `${speedBarWidth()}%`,
                            backgroundColor: speedLevel === 'Fast' ? 'green' : speedLevel === 'Medium' ? 'orange' : 'red',
                        }}
                    ></div>
                </div>
            </div>
        </div>
    );
};

export default InternetSpeedChecker;
