import React, { useState } from 'react';
import './ReportTable.css'; // Import CSS for styling

const examReports = [
    { id: 1, name: 'Attendance Report' },
    { id: 2, name: 'Incomplete Status Report' },
    { id: 3, name: 'Candidate Report' },
    { id: 4, name: 'Time Justification Report' },
    { id: 5, name: 'Candidate Duration Report' },
    { id: 6, name: 'Tracking Report' },
    { id: 7, name: 'Exam Closure Summary' },
  
  ];

const bioReports = [
{ id: 1, name: 'API Service'},
{ id: 2, name: 'Seat Allocation'},
{ id: 3, name: 'Skip Validation' },

];

const miscellaneousReports = [
{ id: 1, name: 'Change Bulk Time Slot'},
{ id: 2, name: 'Change Medium'},
{ id: 3, name: 'Candidate Score generation'}, 
{ id: 4, name: 'Image Download'},
{ id: 5, name: 'DB Patch update'},
{ id: 6, name: 'Bulk Time Extension'},
{ id: 7, name: 'Scanner Upload'},
{ id: 8, name: 'Grace Time Extension'}, 

];

// Utility function to split reports into chunks
const chunkArray = (array, size) => {
  const result = [];
  for (let i = 0; i < array.length; i += size) {
    result.push(array.slice(i, i + size));
  }
  return result;
};

const ReportTable = ({ type, onReportSelect }) => {
  const [selectedReport, setSelectedReport] = useState(null);

  const handleReportClick = (report) => {
    setSelectedReport(report);
    onReportSelect(report);
  };

  const handleClosePopup = () => {
    setSelectedReport(null);
    onReportSelect(null);

  };

  // Split reports into chunks of 4 per row
  let reports = [];
  if (type === 'exam') {
    reports = examReports;
  } else if (type === 'biometric') {
    reports = bioReports;
  } else if (type === 'miscellaneous') {
    reports = miscellaneousReports;
  }
  const rows = chunkArray(reports, 2);

  return (
    <div className="report-table-container">
      <table className="report-table">
        <tbody>
          {rows.map((row, rowIndex) => (
            <tr key={rowIndex}>
              {row.map((report) => (
                <td key={report.id} onClick={() => handleReportClick(report)}>
                  {report.name}
                </td>
              ))}
              {row.length < 4 && (
                <td colSpan={6 - row.length}></td> // Add empty cells if row has less than 4 items
              )}
            </tr>
          ))}
        </tbody>
      </table>

      {selectedReport && (
        <div className="popup">
          <div className="popup-content">
            <span className="close-btn" onClick={handleClosePopup}>&times;</span>
            <h2>{selectedReport.name}</h2>
            {type == 'exam' ? (
                <>
                <p>This is some exam dummy content for the report.</p>
                </>
            ) : type == 'biometric' ? (
            <>
                <p>This is some biometric dummy content for the report.</p>
            </>):type == 'miscellaneous' ? (
            <>
                <p>This is some miscellaneous dummy content for the report.</p>
            </>):(<></>)}
            
          </div>
        </div>
      )}
    </div>
  );
};

export default ReportTable;
