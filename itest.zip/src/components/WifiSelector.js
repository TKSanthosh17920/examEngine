import React, { useState, useEffect } from 'react';

const WifiSelector = () => {
  const [networks, setNetworks] = useState([]);
  const [selectedNetwork, setSelectedNetwork] = useState('');
  const [password, setPassword] = useState('');
  const [passwordRequired, setPasswordRequired] = useState(false);
  const [connectedNetwork, setConnectedNetwork] = useState('');
  const [isConnected, setIsConnected] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');
  const [error, setError] = useState(null);
  // Fetch available networks on component mount
  useEffect(() => {
    let intervalId;

    const fetchNetworks = async () => {
      try {
        const response = await fetch('http://localhost:5001/api/networks');
        if (!response.ok) {
          throw new Error('Network response was not ok');
        }
        const data = await response.json();
        setNetworks(data);
        console.log('Fetched networks data:', data);
      } catch (err) {
        setError('Error fetching networks data');
        console.error('Error fetching networks:', err);
      }
    };

    const fetchConnection = async () => {
      try {
        const response = await fetch('http://localhost:5001/api/current-connection');
        if (!response.ok) {
          throw new Error('Network response was not ok');
        }
        const data = await response.json();
        if (data.ssid) {
          setConnectedNetwork(data.ssid);
          setIsConnected(true);
        } else {
          setConnectedNetwork('Not connected');
          setIsConnected(false);
        }
      } catch (err) {
        setError('Error fetching current connection');
        console.error('Error fetching current connection:', err);
      }
    };

    fetchNetworks();  // Fetch immediately on mount
    fetchConnection();  // Fetch immediately on mount

    intervalId = setInterval(() => {
      fetchNetworks();  // Fetch networks every second
    }, 1000);

    // Cleanup interval on component unmount
    return () => clearInterval(intervalId);
  }, []);


  const handleNetworkSelection = (network) => {
    setSelectedNetwork(network.SSID);
    setPasswordRequired(network.Authentication !== 'Open'); 
    setPassword(''); // Clear the password field when changing networks
    setErrorMessage(''); // Clear any error messages
};



const handleConnect = () => {
    if (!selectedNetwork) {
      setErrorMessage('Please select a network.');
      return;
    }
    if (passwordRequired && !password) {
      setErrorMessage('Password is required for this network.');
      return;
    }

    fetch('http://localhost:5001/api/connect', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        ssid: selectedNetwork,
        password: passwordRequired ? password : null,
      }),
    })
      .then((res) => res.json())
      .then((data) => {
        if (data.success) {
          setIsConnected(true);
          setErrorMessage('');
        } else {
          setErrorMessage(data.message || 'Failed to connect to the network.');
        }
      })
      .catch((error) => {
        console.error('Error connecting to network:', error);
        setErrorMessage('Error connecting to the network.');
      });
  };
  

  const handleDisconnect = () => {
    fetch('http://localhost:5001/api/disconnect', {
      method: 'POST',
    })
      .then((res) => res.json())
      .then((data) => {
        if (data.success) {
          setConnectedNetwork('Not connected');  // Reset the connected network
          setIsConnected(false);                 // Update connected status
          setErrorMessage('');                   // Clear any error messages
        } else {
          setErrorMessage(data.message || 'Failed to disconnect.');
        }
      })
      .catch((error) => {
        console.error('Error disconnecting from network:', error);
        setErrorMessage('Error disconnecting from the network.');
      });
  };

  return (
    <div>
      <h3>Select Wi-Fi Network</h3>
      <ul>
        {networks.map((network) => (
          <li key={network.SSID}>
            <input
              type="radio"
              name="network"
              value={network.SSID}
              onChange={() => handleNetworkSelection(network)}
            />
            {network.SSID} ({network.Signal}) 
            {network.Authentication !== 'Open' ? ' - Password required' : ' - Open network'}
          </li>
        ))}
      </ul>

      {passwordRequired && (
        <input
          type="password"
          placeholder="Enter Wi-Fi password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
        />
      )}

      <button onClick={handleConnect} disabled={!selectedNetwork}>
        Connect
      </button>

      {errorMessage && <p style={{ color: 'red' }}>{errorMessage}</p>}

      <div>
        <h4>Connection Status</h4>
        {isConnected ? (
          <p>
            Connected to: <strong>{connectedNetwork}</strong>
          </p>
        ) : (
          <p>Not connected</p>
        )}
      </div>

      {isConnected && (
        <button onClick={handleDisconnect}>
          Disconnect
        </button>
      )}
    </div>
  );
};

export default WifiSelector;
