const express = require('express');
const { exec,spawn  } = require('child_process');
const app = express();
const wifi = require('node-wifi');
const cors = require('cors');
const port = 5001; // Use a commonly used port if 6000 is problematic


// Initialize wifi module
wifi.init({
    iface: null // network interface, leave it null for the default interface
  });

app.use(express.json());
app.use(cors({
    origin: 'http://localhost:3000',
    methods: 'GET,HEAD,PUT,PATCH,POST,DELETE',
    credentials: true,
}));



app.post('/api/restart/:service', (req, res) => {
    const service = req.params.service;
    let command;
    console.log('Service:', service);

    switch (service) {
        case 'exam':
            command = `powershell.exe -Command "Restart-Service -Name 'ExamServiceName'"`;
            break;
        case 'react':
            command = 'pm2 restart react-app';
            break;
        case 'node':
            command = 'pm2 restart itest'; 
            break;
        case 'mysql':
            command = `powershell.exe -Command "Restart-Service -Name 'MySQL'"`;
            break;
        case 'memcache':
            command = `powershell.exe -Command "Restart-Service -Name 'Memcached'"`;
            break;
        default:
            return res.status(400).send('Invalid service');
    }

    console.log('Executing command:', command);

    exec(command, (error, stdout, stderr) => {
        if (error) {
            console.error(`Error restarting ${service}:`, error);
            console.error(`stderr:`, stderr);
            return res.status(500).send(`Failed to restart ${service}`);
        }
        console.log(`stdout for ${service}:`, stdout);
        res.send(`Restart command sent for ${service}`);
    });
});




// Endpoint to scan available networks
app.get('/api/networks', (req, res) => {
    const scanNetworks = spawn('netsh', ['wlan', 'show', 'networks', 'mode=Bssid'], {
      detached: true,
      stdio: ['ignore', 'pipe', 'pipe'] // Ignore input, pipe output
    });
  
    let networks = '';
  
    scanNetworks.stdout.on('data', (data) => {
      networks += data.toString();
    });
  
    scanNetworks.stderr.on('data', (data) => {
      console.error(`Error scanning networks: ${data}`);
      res.status(500).json({ error: 'Failed to scan networks', details: data.toString() });
    });
  
    scanNetworks.on('close', (code) => {
      if (code === 0) {
        // Process the networks data (networks variable) to send the response
        const parsedNetworks = parseNetworksData(networks); // You need to implement this function to parse the data
        res.json(parsedNetworks);
      } else {
        console.error(`Scan process exited with code ${code}`);
        res.status(500).json({ error: 'Failed to scan networks' });
      }
    });
  
    scanNetworks.unref(); // Run in detached mode
  });
  

  function parseNetworksData(networks) {
    const lines = networks.split('\n');
    const parsedNetworks = [];
    let currentNetwork = null;
    // console.log(networks);
    lines.forEach(line => {
        line = line.trim(); // Trim any extra whitespace

        if (line.startsWith('SSID')) {
            if (currentNetwork) {
                // Save the previous network data if it exists
                parsedNetworks.push(currentNetwork);
            }
            currentNetwork = { SSID: line.split(':')[1].trim() };
        } else if (line.startsWith('BSSID')) {
            if (currentNetwork) {
                currentNetwork.BSSID = line.split(':')[1].trim();
            }
        } else if (line.startsWith('Signal')) {
            if (currentNetwork) {
                currentNetwork.Signal = line.split(':')[1].trim();
            }
        } else if (line.startsWith('Network type')) {
            if (currentNetwork) {
                currentNetwork.Security = line.split(':')[1].trim();
            }
        } else if (line.startsWith('Authentication')) {
            if (currentNetwork) {
                currentNetwork.Authentication = line.split(':')[1].trim();
            }
        }
    });

    if (currentNetwork) {
        parsedNetworks.push(currentNetwork); // Push the last network
    }

    return parsedNetworks;
}



app.post('/api/connect', (req, res) => {
    const { ssid, password } = req.body;
  
    if (!ssid) {
      return res.status(400).json({ success: false, message: 'SSID is required' });
    }
  
    // Construct the command to connect to the Wi-Fi network
    const command = password
      ? `netsh wlan add profile name="${ssid}" ssid="${ssid}" key="${password}" && netsh wlan connect name="${ssid}" ssid="${ssid}"`
      : `netsh wlan connect name="${ssid}" ssid="${ssid}"`;
  
    exec(command, (error, stdout, stderr) => {
      if (error) {
        console.error(`Error: ${stderr}`);
        return res.status(500).json({ success: false, message: stderr });
      }
      res.json({ success: true, message: stdout });
    });
  });
  
  

  // API endpoint to disconnect from Wi-Fi
  app.post('/api/disconnect', (req, res) => {
    // Spawn the `netsh` process in a detached mode
    const disconnect = spawn('netsh', ['wlan', 'disconnect'], {
      detached: true, // Run the process independently of the parent process
      stdio: 'ignore' // Ignore any output to avoid opening a command prompt
    });
  
    // Disconnect process to avoid the command prompt window
    disconnect.unref();
  
    disconnect.on('error', (err) => {
      console.error('Error disconnecting from Wi-Fi:', err);
      return res.status(500).json({ message: 'Failed to disconnect from Wi-Fi' });
    });
  
    disconnect.on('close', (code) => {
      if (code === 0) {
        console.log('Successfully disconnected from Wi-Fi');
        res.json({ message: 'Successfully disconnected from Wi-Fi' });
      } else {
        console.error(`Disconnect process exited with code ${code}`);
        res.status(500).json({ message: 'Failed to disconnect from Wi-Fi' });
      }
    });
  });
  

  


// Endpoint to get the current Wi-Fi connection
app.get('/api/current-connection', (req, res) => {
    const getCurrentConnection = spawn('netsh', ['wlan', 'show', 'interfaces'], {
      detached: true,
      stdio: ['ignore', 'pipe', 'pipe'], // Ignore input, capture output and errors
    });
  
    let output = '';
  
    getCurrentConnection.stdout.on('data', (data) => {
      output += data.toString();
    });
  
    getCurrentConnection.stderr.on('data', (data) => {
      console.error(`Error getting current connection: ${data}`);
      res.status(500).json({ error: 'Failed to get current connection', details: data.toString() });
    });
  
    getCurrentConnection.on('close', (code) => {
      if (code === 0) {
        const parsedConnection = parseCurrentConnection(output); // Parse the raw output
        if (parsedConnection) {
          res.json(parsedConnection);
        } else {
          res.json({ message: 'No Wi-Fi connection' });
        }
      } else {
        console.error(`Current connection process exited with code ${code}`);
        res.status(500).json({ error: 'Failed to get current connection' });
      }
    });
  
    getCurrentConnection.unref(); // Run in detached mode
  });
  
  // Function to parse the current Wi-Fi connection details
  const parseCurrentConnection = (output) => {
    const ssidMatch = output.match(/SSID\s+:\s(.*)/);
    const signalMatch = output.match(/Signal\s+:\s(.*%)/);
  
    if (ssidMatch && signalMatch) {
      return {
        ssid: ssidMatch[1].trim(),
        signal_level: signalMatch[1].trim(),
      };
    }
    return null; // Return null if no match is found (meaning no active connection)
  };

  
  
app.listen(port, () => {
    console.log(`Node.js servers running on port ${port}`);
});
